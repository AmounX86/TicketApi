export interface Ticket {
    ticketID?: number;
    creationDate?: Date;
    phone?: string;
    governorate?: string;
    city?: string;
    district?: string;
}
