import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Ticket } from './ticket';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from './../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TicketService {

  constructor(private http: HttpClient) { }

  ticketCreate(ticket: Ticket): Observable<Ticket>{
    return this.http.post<Ticket>(environment.apiURL+"/Ticket", ticket);
  }

  ticketList(page: number): Observable<Ticket[]>{
    return this.http.get<Ticket[]>(environment.apiURL+"/Ticket/"+page);
  }
}
