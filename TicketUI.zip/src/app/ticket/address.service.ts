import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from './../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AddressService {

  constructor(private http: HttpClient) { }

  getGovs(): Observable<string[]>{
    return this.http.get<string[]>(environment.apiURL+"/Ticket/GovList");
  }

  getCities(): Observable<string[]>{
    return this.http.get<string[]>(environment.apiURL+"/Ticket/CityList");
  }

  getDistricts(): Observable<string[]>{
    return this.http.get<string[]>(environment.apiURL+"/Ticket/DistrictList");
  }
}
